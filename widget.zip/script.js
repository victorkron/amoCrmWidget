define(['jquery', 'underscore', 'twigjs'], function ($, _, Twig) {
  var CustomWidget = function () {
    var self = this;

    this.delay = function delay(time) {
      let start = Number(new Date());
      while ( Number(new Date()) - start < time ) {

      }
    },

    this.firstParam = null;
    this.secondParam = null;
    this.result = null;


    this.callbacks = {
      render: function () {
        console.log('render');

        let firstElem = document.querySelector(`input[name="CFV[${self.firstParam}]"]`);
        let secondElem = document.querySelector(`input[name="CFV[${self.secondParam}]"]`);
        let resultElem = document.querySelector(`input[name="CFV[${self.result}]"]`);

        if (!firstElem.value) { // установка дефолтного значения как на видеоролике к заданию
          firstElem.value = 1;
        }

        if (!secondElem.value) { // -----||-----
          secondElem.value = 2;
        }

        resultElem.readOnly = true;
        resultElem.value = Number(firstElem.value) + Number(secondElem.value);

        firstElem.addEventListener('input', (event) => {
          resultElem.value = Number(firstElem.value) + Number(secondElem.value);
        });

        secondElem.addEventListener('input', (event) => {
          resultElem.value = Number(firstElem.value) + Number(secondElem.value);
        });

        return true;
      },
      init: _.bind(function () {
        console.log('init');

        AMOCRM.addNotificationCallback(self.get_settings().widget_code, function (data) {
          console.log(data)
        });

        return true;
      }, this),
      bind_actions: function () {
        console.log('bind_actions');
        return true;
      },
      settings: function () {
        var $modal_body = $('.modal.' + self.get_settings().widget_code + ' .modal-body'),
            $widget_settings = $modal_body.find('.widget_settings_block');

        $widget_settings.html(
          '<div class="signature">Первое слогаемое:</div>' +
          self.render({ ref: '/tmpl/controls/select.twig' }, {
            name: 'firstParam',
            id: 'param1',
            items: [
              { id: 1, option: 'Номер телефона' },
              { id: 2, option: 'Стоимость' },
              { id: 3, option: 'a' },
              { id: 4, option: 'b' },
              { id: 5, option: 'c' },
            ],
            selected: 1,
            class_name: 'myCustomForSelect',
            button_class_name: 'buttonForSelect btnFirstSelect',
            input_special_class: 'inputClass',
          }) + '<div class="signature">Второе слогаемое:</div>' +
          self.render({ ref: '/tmpl/controls/select.twig' }, {
            name: 'secondParam',
            id: 'param2',
            items: [
              { id: 1, option: 'Номер телефона' },
              { id: 2, option: 'Стоимость' },
              { id: 3, option: 'a' },
              { id: 4, option: 'b' },
              { id: 5, option: 'c' },
            ],
            selected: 1,
            class_name: 'myCustomForSelect',
            button_class_name: 'buttonForSelect btnSecondSelect',
            input_special_class: 'inputClass',
          }) + '<div class="signature">Результат</div>' +
          self.render({ ref: '/tmpl/controls/select.twig' }, {
            name: 'Result',
            id: 'res',
            items: [
              { id: 1, option: 'Номер телефона' },
              { id: 2, option: 'Стоимость' },
              { id: 3, option: 'a' },
              { id: 4, option: 'b' },
              { id: 5, option: 'c' },
            ],
            selected: 1,
            class_name: 'myCustomForSelect',
            button_class_name: 'buttonForSelect btnResultSelect',
            input_special_class: 'inputClass',
          }) +
          self.render({ ref: '/tmpl/controls/button.twig' }, {
            name: 'checkbox',
            text: 'Сохранить',
            class_name: 'saveBtn',
            blue: false
          })
        );

        let saveBtn = document.querySelector('.saveBtn');
        let firstBtn = document.querySelector('.btnFirstSelect');
        let secondBtn = document.querySelector('.btnSecondSelect');
        let resBtn = document.querySelector('.btnResultSelect');

        let arrSelect = Array.from(document.querySelectorAll('.myCustomForSelect'));
        let arrSign = Array.from(document.querySelectorAll('.signature'));

        arrSign.forEach((item, i) => {
          item.style.marginTop = '3vh';
        });

        arrSelect.forEach((item, i) => {
          item.style.marginTop = '1vh';
        });

        saveBtn.style.marginTop = '4vh';

        let arrID = []; // для получения айдишников созданных элементов

        function createRequest(method, address) {
          let myRequest = new XMLHttpRequest();
          myRequest.open(method, address);
          myRequest.setRequestHeader('Content-Type', 'application/json');
          return myRequest;
        }

        function sendRequest(request, obj) {
          let id = null;
          objStringify = JSON.stringify(obj);

          self.delay(300);

          request.send(objStringify);
          request.onreadystatechange = function functionName() {
            if(request.readyState == 4) {
              if (request.status != 200) {
                console.log( request.status + ': ' + request.statusText );
              } else {
                console.log( request.responseText );
                id = JSON.parse(request.response)._embedded.custom_fields[0].id;
                arrID.push(id);
              }
              self.firstParam = arrID[2];
              self.secondParam = arrID[1];
              self.result = arrID[0];
            }
          }
        }

        saveBtn.addEventListener('click', () => {

          // let myRequest = createRequest('POST', 'https://kkron2015.amocrm.ru/api/v4/leads');
          // let objDeal = [
          //   {
          //     "name": "Сделка пример 2",
          //     "created_by": 0,
          //     "price": 20000,
          //
          //   }
          // ];
          // sendRequest(myRequest, objDeal);

          let resultCustomField = createRequest('POST', 'https://kkron2015.amocrm.ru/api/v4/leads/custom_fields');
          let objResultCustomField = [
            {
              "name": `${resBtn.innerText}`,
              "type": "numeric",
              "enums": null
            }
          ]
          let resElemID = sendRequest(resultCustomField, objResultCustomField);

          let secondCustomField = createRequest('POST', 'https://kkron2015.amocrm.ru/api/v4/leads/custom_fields');
          let objSecondCustomField = [
            {
              "name": `${secondBtn.innerText}`,
              "type": "numeric",
              "enums": null
            }
          ]
          let secondParamElemID = sendRequest(secondCustomField, objSecondCustomField);

          let firstCustomField = createRequest('POST', 'https://kkron2015.amocrm.ru/api/v4/leads/custom_fields');
          let objFirstCustomField = [
            {
              "name": `${firstBtn.innerText}`,
              "type": "numeric",
              "enums": null
            }
          ]

          let firstParamElemID = sendRequest(firstCustomField, objFirstCustomField);
        });

        return true;
      },
      onSave: function () {
        alert('click');
        return true;
      },

    };
    return this;
  };

  return CustomWidget;
});
